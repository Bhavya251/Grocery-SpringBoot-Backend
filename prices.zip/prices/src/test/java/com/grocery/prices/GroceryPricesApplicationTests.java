package com.grocery.prices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryPricesApplicationTests {

	@Test
	void contextLoads() {
	}

}
